import { Component, OnInit } from '@angular/core';
import { User } from '@app/core/models/user';
import { UserService } from './user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})


export class UserComponent implements OnInit {

  users: User[];
  userTableColumns : string[] = ['first_name','last_name','email','phone'];
  dataSource = [{ first_name: 'Chinchu', last_name: 'Kurian', email: 'chinchu.kurian@fingent.com',phone:9876542345 },
  { first_name: 'Sreena', last_name: 'K', email: 'sreena.chandran@fingent.com',phone: 9867432123},
  { first_name: 'Kavitha', last_name: 'Pratheesh', email: 'kavitha.pratheesh@fingent.com'},
  { first_name: 'Revathy', last_name: 'Abhilash', email: 'revathy.abhilash@fingent.com'},
  { first_name: 'Jeena', last_name: 'Nikhil', email: 'jeena.nikhil@fingent.com'}
  ];
  
  constructor(private userService: UserService) { 
    
  }

  ngOnInit(): void {
    this.userService.getUsers().subscribe(data => this.users = data['data']);
    
  }

  

}
